package com.lwh.pedometer;

import java.lang.ref.WeakReference;
import java.util.Stack;

import com.igexin.sdk.PushManager;

import android.app.Application;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobConfig;
import cn.sharesdk.framework.ShareSDK;

public class BaseApplication extends Application implements IConstant,ITimeMillis{

	private volatile static BaseApplication mApp;//整个应用的Application
	private Stack<WeakReference<BaseActivity>> mTasks = new Stack<WeakReference<BaseActivity>>();

	public synchronized static BaseApplication getInstance() {
		return mApp;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		mApp = this;
		initSDK();
		initService();
	}

	private void initSDK() {
		initBmobSDK();
		initGetuiSDK();
		initShareSDK();
	}

	private void initGetuiSDK() {
		PushManager.getInstance().initialize(mApp);
	}

	private void initShareSDK() {
		ShareSDK.initSDK(this);
	}

	private void initBmobSDK() {
		BmobConfig.Builder builder = new BmobConfig.Builder(mApp);
		builder.setApplicationId(BMOB_APP_ID);// Bmob的应用id
		builder.setConnectTimeout(3 * SECOND);// 3秒连接超时
		BmobConfig conf = builder.build();
		Bmob.initialize(conf);
	}

	private void initService() {
//		mApp.startService(new Intent(mApp,PedometerService.class));
//		mApp.startService(new Intent(mApp,RemoteService.class));
	}

	public void pushTask(WeakReference<BaseActivity> task) {
		mTasks.push(task);
	}

	public void removeTask(WeakReference<BaseActivity> task) {
		mTasks.remove(task);
	}

	public void removeTask(int taskIndex) {
		if (mTasks.size() > taskIndex)
			mTasks.remove(taskIndex);
	}

	public void removeToTop() {
		int end = mTasks.size();
		int start = 1;
		for (int i = end - 1; i >= start; i--) {
			if (!mTasks.get(i).get().isFinishing()) {
				mTasks.get(i).get().finish();
			}
		}
	}

	public void removeAll() {
		for (WeakReference<BaseActivity> task : mTasks) {
			if (!task.get().isFinishing()) {
				task.get().finish();
			}
		}
	}
}
