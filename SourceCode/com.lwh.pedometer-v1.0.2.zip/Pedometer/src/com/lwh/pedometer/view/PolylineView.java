package com.lwh.pedometer.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.view.View;

public class PolylineView extends View {

	Paint mGridPaint;
	Paint mPolylinePaint;
	Paint mDatePaint;
	private int[] mStepNums = new int[7];

	public PolylineView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	private void init() {
		mGridPaint = new Paint();
		mGridPaint.setColor(Color.GRAY);
		mGridPaint.setAntiAlias(true);
		mGridPaint.setStyle(Style.STROKE);
		mGridPaint.setStrokeWidth(1);

		mPolylinePaint = new Paint();
		mPolylinePaint.setColor(Color.rgb(230, 53, 40));// 红色
		mPolylinePaint.setAntiAlias(true);
		mPolylinePaint.setStrokeWidth(6);

		mDatePaint = new Paint();
		mDatePaint.setColor(Color.GRAY);
		mDatePaint.setAntiAlias(true);
		mDatePaint.setStyle(Style.STROKE);
		mDatePaint.setStrokeWidth(2);
	}

	public float convertStepNum(int stepNum) {
		float singleHeight = (getHeight() - 40 - 6) / 5;
		float total = 5 * singleHeight + 6;
		return total - total * stepNum / 10000;
	}
	
	public void setStepNums(int[] stepNums){
		mStepNums = stepNums;
		requestLayout();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		float singleWidth = (getWidth() - 40 - 7) / 6;
		drawGrid(canvas);
		for (int i = 0; i < mStepNums .length - 1; i++) {
			drawRedLine(singleWidth * i, convertStepNum(mStepNums [i]), singleWidth * (i + 1),
					convertStepNum(mStepNums [i + 1]), canvas);
		}
	}

	private void drawRedLine(float startX, float startY, float stopX, float stopY, Canvas canvas) {
		canvas.drawLine(startX + 20, startY + 20, stopX + 20, stopY + 20, mPolylinePaint);
	}

	public void drawGrid(Canvas canvas) {
		float singleWidth = (getWidth() - 40 - 7) / 6;
		float singleHeight = (getHeight() - 40 - 6) / 5;
		for (int i = 0; i < 6; i++) {
			canvas.drawLine(20, i * singleHeight + 20, singleWidth * 6 + 20, i * singleHeight + 20, mGridPaint);
		}
		for (int j = 0; j < 7; j++) {
			canvas.drawLine(20 + singleWidth * j, 20, 20 + singleWidth * j, singleHeight * 5 + 20, mGridPaint);
		}
	}

}
