package com.lwh.pedometer;

import com.lwh.pedometer.view.PolylineView;

public class StatFragment extends BaseFragment {

	PolylineView pv_main_stat;
	
	@Override
	protected void doBusiness() {
		int[] stepNums = new int[7];//最近7天的步数
		stepNums[6] = 10000;
		pv_main_stat.setStepNums(stepNums);
	}

}
