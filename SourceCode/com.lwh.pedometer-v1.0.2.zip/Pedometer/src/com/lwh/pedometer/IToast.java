package com.lwh.pedometer;

public interface IToast {
	void toast(String text);
	void toast(String text,int duration);
}
