package com.lwh.pedometer;

import com.alwh.framework.core.OnClick;
import com.lwh.pedometer.view.ColorPickerView;
import com.lwh.pedometer.view.ColorPickerView.OnColorChangedListener;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.view.View;

public class ColorPickActivity extends BaseActivity implements OnColorChangedListener {

	ColorPickerView cpv;
	int mSelectColor;
	
	@Override
	protected void doBusiness() {
		cpv.setOnColorChangedListenner(this);
	}
	@OnClick(R.id.selectcolor_titlebar_back)
	public void back(View v){
		finish();
	}
	@OnClick(R.id.tv_selectcolor_titlebar_confirm)
	public void confirm(View v){
		Editor editor = getSharedPreferences("pedometer", Context.MODE_PRIVATE).edit();
		editor.putInt("theme_color",mSelectColor);
		editor.commit();
		setResult(Activity.RESULT_OK);
		finish();
	}
	@Override
	public void onColorChanged(int color, int originalColor, float saturation) {
		mSelectColor = color;
	}
}
